
https://stackoverflow.com/questions/63229237/finding-the-most-frequent-combination-in-dataframe
https://stackoverflow.com/questions/51562908/python-discord-chatbot-making-a-mood-counter
https://stackoverflow.com/questions/23294658/asking-the-user-for-input-until-they-give-a-valid-response
And the 3 problems in the course helped me in solving this case