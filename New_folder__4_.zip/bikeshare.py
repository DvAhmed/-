import time
import pandas as pd
import numpy as np

CITY_DATA = { 'chicago': 'chicago.csv',
              'new york city': 'new_york_city.csv',
              'washington': 'washington.csv' }
cities=['chicago','new york','washington']
months=['january','february','march','april','may','june','all']
days=['sunday','monday','tuesday','wednesday','thursday','friday','saturday','all']

              
def get_filters():
    """
    Asks user to specify a city, month, and day to analyze.

    Returns:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    """
    print('Hello! Let\'s explore some US bikeshare data!')
    # get user input for city (chicago, new york city, washington). HINT: Use a while loop to handle invalid inputs
    city=input('Frist choose the city you want to explore:chicago,new york or washington: ')
    while city not in ['chicago','new york','washington']:
        print('Invalid city choice.')
        city = input('chicago','new york','washington').lower()
    # get user input for month (all, january, february, ... , june)
    month=input('Which month you want to explore?: ')
    while month not in ['january', 'february', 'march', 'april', 'may', 'june','all']:
        print('Invalid month choice.')
        month = input('january', 'february', 'march', 'april', 'may', 'june','all').lower()

    # get user input for day of week (all, monday, tuesday, ... sunday)
    day=input('Which day you want to explore?: ')
    while day not in ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday','all']:
        print('Invalid day choice.')
        day = input('monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday','all').lower()
    

    print('-'*40)
    return city, month, day


def load_data(city, month, day):
    """
    Loads data for the specified city and filters by month and day if applicable.

    Args:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    Returns:
        df - Pandas DataFrame containing city data filtered by month and day
    """
    df= pd.read_csv(CITY_DATA[city])
    df['Start Time'] = pd.to_datetime(df['Start Time'])
    df['month'] = df['Start Time'].dt.month
    df['day_of_week'] = df['Start Time'].dt.day_name()
    df['common_hour']=df['Start Time'].dt.hour
    if month != 'all':
        months = ['january', 'february', 'march', 'april', 'may', 'june']
        month = months.index(month) + 1
    
    if day!='all':
        df=df[df['day_of_week']==day]
        view_data = input("Would you like to view 5 rows of individual trip data? Enter yes or no?")
        while view_data.lower() =='no':
            break
        start_loc = 0
        while view_data.lower() =='yes':
         print(df.iloc[start_loc:start_loc+5])
        start_loc += 5
        view_data = input("Do you wish to continue?: ").lower()


    return df


def time_stats(df):
    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # display the most common month
    common_month = df['month'].mode()[0]
    print('The most common month is : {}'.format(common_month))

    # display the most common day of week
    common_day = df['day_of_week'].mode()[0]
    print('The most common day of the week is : {}'.format(common_day))

    # display the most common start hour
    common_hour = df['hour_of_day'].mode()[0]
    print('The most common hour of the day is : {}'.format(common_hour))

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # display most commonly used start station
    print(df['Start_Station'].mode()[0])

    # display most commonly used end station
    print(df['End_Station'].mode()[0])

    # display most frequent combination of start station and end station trip
    comb=df.groupby(['Start Station','End Station'])
    print(comb.size.sort_values(ascending=False)).head(1)
    

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # display total travel time
    print(df['Trip Duration'].sum)
    

    # display mean travel time
    print(df['Trip Duration'].mean)

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def user_stats(df):
    """Displays statistics on bikeshare users."""

    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # Display counts of user types
    user_types = df['User Type'].value_counts()
    print(user_types)

    # Display counts of gender
    if 'Gender' in df['Gender']:
                                print(df['Gender'].value_counts())
    # Only access Gender column in this case 
    
    else:
            print('Gender stats cannot be calculated because Gender does not appear in the dataframe')

    # Display earliest, most recent, and most common year of birth
    print(df['Birth Year'].mode()[0])
    print(df['Birth Year'].max())
    print(df['Birth Year'].min())

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

    

def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)

        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df)


        restart = input('\nWould you like to restart? Enter yes or no.\n')
        if restart.lower() != 'yes':
                break


if __name__ == "__main__":
	main()
